/* vim: set sw=8 ts=8 si et: */
/*
* Basic LED test software for the avrusb500 v2 programmer.
* Author: Guido Socher, Copyright: GPL V2
*/
#include "cfg500.h"
#include <inttypes.h>
#include <string.h>
#include <avr/io.h>
#include "led.h"
#include "timeout.h"


int main(void)
{
#ifdef VAR_88CHIP
        // set the clock speed to "no pre-scaler" (8MHz with internal osc or
        // full external speed)
        // set the clock prescaler. First write CLKPCE to enable setting of clock the
        // next four instructions.
        CLKPR=(1<<CLKPCE); // change enable
        CLKPR=0; // "no pre-scaler"
        delay_ms(1);
#endif
        LED_INIT;
        LED_OFF;
        while(1){
                // 1 Hz:
                delay_ms(500);
                LED_ON;
                delay_ms(500);
                LED_OFF;
        }
	return(0);
}

