/* vim: set sw=8 ts=8 si et: */
/*
* SPI speed test. This can be used to tune the delay values
* in the software spi
* Author: Guido Socher, Copyright: GPL V2
*/
#include "timeout.h" // must be first
#include <avr/io.h>
#include <util/delay.h>
#include "spi.h"
#include "led.h"
#include "cfg500.h"
// try different sck_dur values and measure with a
// frequency counter the frequency on the sck output pin.
//
static unsigned char d_sck_dur=254;

// the mapping between SCK freq and SCK_DURATION is for avrisp as follows:
// clock is 14.7MHz
// sck_dur       sck-freq   d_sck_dur
// 0              921kHz     1
//                520kHz     2
//                370kHz     4
//                280kHz     6
// 1              230kHz     8
//                100kHz     22
// 2              57kHz      50
// 3              28kHz      80
// 4              27kHz      90
// 5              26kHz      100
// 7              20kHz      120
// 8              18kHz      140
// 10             15kHz      160
// 15             10kHz      240
// 19             9 kHz      254
// 25             6 kHz    
// 50             3 kHz   
// 100            1.5kHz  


int main(void)
{
        unsigned char i=128;
        unsigned char rval=0;
        unsigned char data=0xaa;
#ifdef VAR_88CHIP
        // set the clock speed to "no pre-scaler" (8MHz with internal osc or
        // full external speed)
        // set the clock prescaler. First write CLKPCE to enable setting of clock the
        // next four instructions.
        CLKPR=(1<<CLKPCE); // change enable
        CLKPR=0; // "no pre-scaler"
        delay_ms(1);
#endif
        LED_INIT;
        LED_ON;
        spi_init();
        // software spi
        PORTD &= ~(1<<PD2); // SCK low
        while(1){
                i=128;
                while(i!=0){
                        // MOSI
                        if (data&i){
                                PORTD|= 1<<PD4;
                        }else{
                                // trans mit a zero
                                PORTD &= ~(1<<PD4);
                        }
                        _delay_loop_1(d_sck_dur);
                        // read MISO
                        if(PIND & (1<<PIND3)){
                                rval|= i;
                        }
                        PORTD|= (1<<PD2); // SCK high
                        _delay_loop_1(d_sck_dur);
                        PORTD &= ~(1<<PD2); // SCK low
                        i=i>>1;
                }
        }
	return(0);
}

