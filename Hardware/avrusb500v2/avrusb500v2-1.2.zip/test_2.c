/* vim: set sw=8 ts=8 si et: */
/*
 * Test the uart communication with the programmer.
 * Echo any characters as hex values back.
 * Author: Guido Socher, Copyright: GPL V2
*/
#include <inttypes.h>
#include <avr/interrupt.h>
#include <stdlib.h> 
#include <string.h>
#include <avr/io.h>
#include "uart.h"
#include "led.h"
#include "timeout.h"
#include "cfg500.h"

int main(void)
{
        char ch;
	char str[10];
#ifdef VAR_88CHIP
        // set the clock speed to "no pre-scaler" (8MHz with internal osc or
        // full external speed)
        // set the clock prescaler. First write CLKPCE to enable setting of clock the
        // next four instructions.
        CLKPR=(1<<CLKPCE); // change enable
        CLKPR=0; // "no pre-scaler"
        delay_ms(1);
#endif
        uart_init();
        LED_INIT;
        LED_OFF;
        sei();
        while(1){
                ch=uart_getchar_noanim(1);
		// echo any input as hex value back (for testing
		// of the connection):
		itoa((int)ch,str,16);
		uart_sendstr_P("0x");
		uart_sendstr(str);
                if (ch == '\n' || ch == '\r' || ch ==' '){
                        continue;
                }
                if (ch == '0'){
                        LED_OFF;
                        uart_sendstr_P("\noff OK\n");
                }else if (ch == '1'){
                        LED_ON;
                        uart_sendstr_P("\non OK\n");
                }else{
                        uart_sendstr_P("\nUSAGE: 1 switch led on\n       0 switch led off\n");
                }
        }
	return(0);
}

