/* vim: set sw=8 ts=8 si et: */
/*
Title:   C include file for configuration of avrusb500 V2
Target:    atmega8/atmega88/atmega168
Copyright: GPL V2
Author: Guido Socher
*/
#ifndef CFG500_H
#define CFG500_H

// remember to change this version string after any update:
#define AVRUSB500VSTR   "avrusb500v2-1.2 \r\n"

// clock speed, please choose one:
// 18.432000 MHz
#define VAR_18CLK 1
// Even the atmega8 will work with 18MHz. There should be no
// need to use the slow 14MHz
// 14.745600 MHz
//#define VAR_14CLK 1


// do not change here! Edit the beginning of the Makefile
#if defined (__AVR_ATmega168__)
#define VAR_88CHIP 1
#elif defined (__AVR_ATmega8__)
#define VAR_8CHIP 1
#elif defined (__AVR_ATmega88__)
#define VAR_88CHIP 1
#endif


#endif /* CFG500_H */
